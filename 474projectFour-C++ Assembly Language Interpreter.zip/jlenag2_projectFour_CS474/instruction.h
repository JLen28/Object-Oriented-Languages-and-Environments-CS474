#include <iostream>
#include <fstream>
#include <string>
#include <math.h> 
using namespace std; 
// coded by Joseph Lenaghan for CS 474 project four at UIC during fall 2022 | UIN : 676805596 | my last project at UIC, how exciting!
class Hardware; // forward decleration of Hardware lets Instruction make use of it for creating its virtual function
 
class Instruction { // Instruction superclass
    public:
      virtual void execute(Hardware &pc, int &programCounter) = 0; // abstract function to be reimplemented in sublcasses
      string printString; // requested variable printString
      string argValue; // requested variable argValue

      void print(){ // requested function print that prints the printString and argValue data members
        cout << "opCode: " + printString << endl;
        cout << printString + " value: " + argValue << endl;
      }

      string getOpCode(){
        return printString;
      }
}; // end of instruction superclass

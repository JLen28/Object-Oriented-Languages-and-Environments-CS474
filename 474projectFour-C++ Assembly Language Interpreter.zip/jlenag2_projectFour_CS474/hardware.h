#include <iostream>
#include <fstream>
#include <string>
#include <math.h> 
#include "instruction.h" // have to include this so we can have our instruction array
using namespace std; 
// Required hardware class that implements all of the requested data members as well as a few additional ones
// coded by Joseph Lenaghan for CS 474 project four at UIC during fall 2022 | UIN : 676805596 | my last project at UIC, how exciting!
class Hardware {
  public:
   int overflow_bit; // overflow bit
   int zero_result_bit; // zero bit 
   int instructionCount; // the number of instructions for the program
   string regA; // accumulator
   string regB; // additional register
   Instruction* progMem[128]; // array that holds program instructions
   string dataMem[128]; // array that holds program data values 


   Hardware(){ // constructor
     for(int i = 0; i < 128; i++){
       dataMem[i] = "0";
     }
     regA = "0";
     regB = "0";
     overflow_bit = 0;
     zero_result_bit = 0;
     instructionCount = 0; // number of instructions maintained by the hardware in progMem
   } // end of constructor


   string getRegA(){ // register A getter
     return regA;
   }


   string getRegB(){ // register B getter
     return regB;
   }


   Instruction* getProgMemLocation(int value){ // get a location in program memory
     return progMem[value];
   }


   string getDataMemLocation(int value){ // get a location in data memory
     return dataMem[value];
   }

  string* getDataMem(){
    return dataMem;
  }

   int getZeroBit(){ // get the zero_result_bit
     return zero_result_bit;
   }


   int getOverflowBit(){ // get the overflow bit
     return overflow_bit;
   }


   int getProgMemSize(){ // the instruction count accurately reflects the number of instructions and thus the program memory size
     return instructionCount;
   }

   int getInstructionCount(){ // return the number of instructions in program memory
     return instructionCount;
   }

   void setProgMemLocation(int location,Instruction* inst){ // set a specific location in program memory with a new instruction
     progMem[location] = inst;
   }


   void setDataMemLocation(int location,string value){ // set a specific location in data memory with a new instruction
     dataMem[location] = value;
   }


   void setOverflowBit(){ // set the overflow bit 
       overflow_bit = 1; // set it
   }

   void clearBits(){ // function that quickly clears both bits, kept seperate from clearData() so it can also be used when a successful ADD operation occurs
     overflow_bit = 0;
     zero_result_bit = 0;
   }

   void setZeroResultBit(){ // set the zero result bit
       zero_result_bit = 1; // set it
   }

   void incrementInstructionCount(){ // increment the instructionCount by one, only utilized during the gathering and storage of instructions
     instructionCount = instructionCount + 1;
   }


  void setRegA(string value){ // setter for register A
    regA = value;
  }


  void setRegB(string value){ // setter for register B
    regB = value;
  }


}; // end of the Hardware class

// coded by Joseph Lenaghan for CS 474 project four at UIC during fall 2022 | UIN : 676805596 | my last project at UIC, how exciting!
#include <iostream>
#include <fstream>
#include <string>
#include <math.h> 
#include "hardware.h"
using namespace std; 


// DEC instruction class
class DEC : public Instruction {
  public:
    DEC(){
      printString = "DEC";
      argValue = "";
    }

    DEC(string value){
      printString = "DEC";
      argValue = value;
    }

    DEC(DEC &nuInst){
      printString = nuInst.printString;
      argValue = nuInst.argValue;
    }

    void execute(Hardware &pc, int &programCounter) { // inherited abstract function from superclass Instruction
      for(int i = 0; i < 128; i++){ // searching the data array
        if(pc.getDataMemLocation(i) == "0"){ // the space is unoccupied
          pc.setDataMemLocation(i,argValue); // occupy it
          return;
        }
      }
    }
};
// end of DEC instruction class


// LDA instruction class
class LDA : public Instruction {
  public:
    LDA(){
      printString = "LDA";
      argValue = "";
    }

    LDA(string value){
      printString = "LDA";
      argValue = value;
    }

    LDA(LDA &nuInst){
      printString = nuInst.printString;
      argValue = nuInst.argValue;
    }


    void execute(Hardware &pc, int &programCounter) { // inherited abstract function from superclass Instruction
        for(int i = 0; i < 128; i++){ // search through the data array
          if(pc.getDataMemLocation(i).find(argValue) != string::npos){ // find the relevant symbol
            string value = pc.getDataMemLocation(i).substr(argValue.length() + 1, pc.getDataMemLocation(i).length()); // start from the equals sign onwards
            pc.setRegA(value); // store the symbol's value into the accumulator
            return;
          }
        }
    }
};
// end of LDA instruction class


// LDB instruction class 
class LDB : public Instruction {
  public:
    LDB(){
      printString = "LDB";
      argValue = "";
    }

    LDB(string value){
      printString = "LDB";
      argValue = value;
    }

    LDB(LDB &nuInst){
      printString = nuInst.printString;
      argValue = nuInst.argValue;
    }


    void execute(Hardware &pc, int &programCounter) { // inherited abstract function from superclass Instruction
          for(int i = 0; i < 128; i++){ // search through the data array
          if(pc.getDataMemLocation(i).find(argValue) != string::npos){ // find the relevant symbol
            string value = pc.getDataMemLocation(i).substr(argValue.length() + 1, pc.getDataMemLocation(i).length()); // start from the equals sign onwards
            pc.setRegB(value); // store the symbol's value into the additional register
            return;
          }
        }
    }
};
// end of LDB instruction class


// LDI instruction class
class LDI : public Instruction {
  public:
    LDI(){
      printString = "LDI";
      argValue = "";
    }

    LDI(string value){
      printString = "LDI";
      argValue = value;
    }

    LDI(LDI &nuInst){
      printString = nuInst.printString;
      argValue = nuInst.argValue;
    }


    void execute(Hardware &pc, int &programCounter) { // inherited abstract function from superclass Instruction
      pc.setRegA(argValue); // load LDI's value into the accumulator
      return;
    }
};
// end of LDI instruction class


// STR instruction class
class STR : public Instruction {
  public:
    STR(){
      printString = "STR";
      argValue = "";
    }

    STR(string value){
      printString = "STR";
      argValue = value;
    }

    STR(STR &nuInst){
      printString = nuInst.printString;
      argValue = nuInst.argValue;
    }


    void execute(Hardware &pc, int &programCounter) { // inherited abstract function from superclass Instruction
      for(int i = 0; i < 128; i++){ // looking through the data array
        if(pc.getDataMemLocation(i).find(argValue) != string::npos){ // found the symbol we're looking for
          pc.setDataMemLocation(i,argValue + "=" + pc.getRegA()); //  store the value in the accumulator into the specified symbol in data memory
          return;
        }
      }
    }
};
// end of STR instruction class


// JMP instruction class
class JMP : public Instruction {
  public:
    JMP(){
      printString = "JMP";
      argValue = "";
    }

    JMP(string value){
      printString = "JMP";
      argValue = value;
    }

    JMP(JMP &nuInst){
      printString = nuInst.printString;
      argValue = nuInst.argValue;
    }


    void execute(Hardware &pc, int &programCounter) { // inherited abstract function from superclass Instruction
      programCounter = stoi(argValue) - 1; // "jumping" the programCounter to the instruction requested
      return;
    }
};
// end of JMP instruction class


// JZS instruction class
class JZS : public Instruction {
  public:
    JZS(){
      printString = "JZS";
      argValue = "";
    }

    JZS(string value){
      printString = "JZS";
      argValue = value;
    }

    JZS(JZS &nuInst){
      printString = nuInst.printString;
      argValue = nuInst.argValue;
    }


    void execute(Hardware &pc, int &programCounter) { // inherited abstract function from superclass Instruction
      if(pc.getZeroBit() == 1){
        programCounter = stoi(argValue) - 1; // "jumping" the programCounter to the instruction requested only if the zero bit is set  
      }
    }
};
// end of JZS instruction class


// JVS instruction class
class JVS : public Instruction {
  public:
    JVS(){
      printString = "JVS";
      argValue = "";
    }

    JVS(string value){
      printString = "JVS";
      argValue = value;
    }

    JVS(JVS &nuInst){
      printString = nuInst.printString;
      argValue = nuInst.argValue;
    }


    void execute(Hardware &pc, int &programCounter) { // inherited abstract function from superclass Instruction
      if(pc.getOverflowBit() == 1){
        programCounter = stoi(argValue) - 1; // "jumping" the programCounter to the instruction requested only if the overflow bit is set add minus because the programCounter increments after every execution
      }
    }
};
// end of JVS instruction class


// ADD instruction class
class ADD : public Instruction {
  public:
    ADD(){
      printString = "ADD";
      argValue = "";
    }

    void execute(Hardware &pc, int &programCounter) { // inherited abstract function from superclass Instruction
      int result = stoi(pc.getRegA()) + stoi(pc.getRegB()); // obtain the result of adding the accumulators together
      if(result > pow(2,31-1) || result < pow(-2,31)){ // is it an overflow?
        pc.setOverflowBit(); // it is, set overflow bit and do not store the value into the accumulator
        return;
      }
      else if(result == 0){ // did the addition return a zero?
        pc.setZeroResultBit(); // it did, set the zero result bit
        pc.setRegA("0"); // store zero 
        return;
      }
      else{
        pc.clearBits(); // set the overflow and zero bit back to zero
        pc.setRegA(to_string(result)); // store the result of the add operation into the accumulator
        return;
      }
    }
};
// end of ADD instruction class


// XCH instruction class
class XCH : public Instruction {
  public:
    XCH(){
      printString = "XCH";
      argValue = "";
    }

    void execute(Hardware &pc, int &programCounter) { // inherited abstract function from superclass Instruction
      string old = pc.getRegA(); // hold onto A's old value
      pc.setRegA(pc.getRegB()); // give A B's old value
      pc.setRegB(old); // give B A's old value
    }
};
// end of XCH instruction class



// HLT instruction class
class HLT : public Instruction {
  public:
    HLT(){
      printString = "HLT";
      argValue = "";
    }

    void execute(Hardware &pc, int &programCounter) { // inherited abstract function from superclass Instruction
      cout << "Halt statement found, exiting program!" << endl << endl;
      exit(0); // HLT statement means shows over, exit the program!
    }
};
// end of HLT instruction class


//////////////////////////////////////////////////////////////////////
///////////////////// END OF INSTRUCTION CLASSES /////////////////////
//////////////////////////////////////////////////////////////////////


class ALI { // class that handles the commandLoop as well as loading the input SAL file and filling the program memory with instructions
    public:
    int programCounter; // program counter used to keep track of the instruction that needs to be executed
    ALI(){
      programCounter = 0; // need to start at the first instruction in program memory
    }
    void readFile(Hardware &pc){ // function that reads a file,and handles loading the instructions into the hardware's program memory
        string selection; // string that will store the user's file selection
        cout << "what file would you like to open? " << endl; // prompt the user to enter a file
        cin >> selection; // capture that file and store it in selection
        fstream inputFile(selection); // opening up a stream for input
        if(inputFile.is_open()){ 
          while(!inputFile.eof()){
            string line; // the line to be split up
            string value;
            getline(inputFile,line); // grab the a line from the file
            if(line == ""){
              continue;
            }
            else{
              string instr = line.substr(0,3); // the operation
              if(instr == "ADD" || instr == "XCH" || instr == "HLT"){
                  value = "";
              }
              else{
                value = line.substr(4,line.length()); // the value of for the operation
              }
              // need to split the two of these up so we can create an Instruction sublcass to add to the program memory in Hardware
              if(instr == "DEC"){
                DEC* nuInstr = new DEC(value);
                pc.setProgMemLocation(pc.getInstructionCount(),nuInstr); // add the instruction to program memory
                pc.incrementInstructionCount(); // increment the counter to reflect an instruction added to memory
              }
              else if(instr == "LDA"){ 
                LDA* nuInstr = new LDA(value);
                pc.setProgMemLocation(pc.getInstructionCount(),nuInstr); // add the instruction to program memory
                pc.incrementInstructionCount(); // increment the counter to reflect an instruction added to memory
              }
              else if(instr == "LDB"){
                LDB* nuInstr = new LDB(value);
                pc.setProgMemLocation(pc.getInstructionCount(),nuInstr); // add the instruction to program memory
                pc.incrementInstructionCount(); // increment the counter to reflect an instruction added to memory
              }
              else if(instr == "LDI"){
                LDI* nuInstr = new LDI(value); 
                pc.setProgMemLocation(pc.getInstructionCount(),nuInstr); // add the instruction to program memory
                pc.incrementInstructionCount(); // increment the counter to reflect an instruction added to memory
              }
              else if(instr == "STR"){
                STR* nuInstr = new STR(value);
                pc.setProgMemLocation(pc.getInstructionCount(),nuInstr); // add the instruction to program memory
                pc.incrementInstructionCount();  // increment the counter to reflect an instruction added to memory
              }
              else if(instr == "XCH"){
                XCH* nuInstr = new XCH();
                pc.setProgMemLocation(pc.getInstructionCount(),nuInstr); // add the instruction to program memory
                pc.incrementInstructionCount(); // increment the counter to reflect an instruction added to memory 
              }
              else if(instr == "JMP"){
                JMP* nuInstr = new JMP(value);
                pc.setProgMemLocation(pc.getInstructionCount(),nuInstr); // add the instruction to program memory
                pc.incrementInstructionCount(); // increment the counter to reflect an instruction added to memory
              }
              else if(instr == "JZS"){
                JZS* nuInstr = new JZS(value);
                pc.setProgMemLocation(pc.getInstructionCount(),nuInstr); // add the instruction to program memory
                pc.incrementInstructionCount(); // increment the counter to reflect an instruction added to memory
              }
              else if(instr == "JVS"){
                JVS* nuInstr = new JVS(value);
                pc.setProgMemLocation(pc.getInstructionCount(),nuInstr); // add the instruction to program memory
                pc.incrementInstructionCount(); // increment the counter to reflect an instruction added to memory
              }
              else if(instr == "ADD"){
                ADD* nuInstr = new ADD();
                pc.setProgMemLocation(pc.getInstructionCount(),nuInstr); // add the instruction to program memory
                pc.incrementInstructionCount(); // increment the counter to reflect an instruction added to memory
              }
              else if(instr == "HLT"){
                HLT* nuInstr = new HLT();
                pc.setProgMemLocation(pc.getInstructionCount(),nuInstr); // add the instruction to program memory
                pc.incrementInstructionCount(); // increment the counter to reflect an instruction added to memory
              }
            }
          }
        } 
        else{ // the file could not open, meaning there was likely a typo...
          cout << "File could not be found, try again please!" << endl; 
          readFile(pc);
        }
        inputFile.close(); // making sure to close the stream
      } // end of readFile

      void commandLoop(Hardware &pc) { // command loop that handles user input
        string input; // string used to capture user input
        
        if(programCounter >= pc.getInstructionCount()){ // if we get here that means there are no more instructions to process, we can conclude execution
          cout << "All instructions processed! Exiting...";
          exit(0); // exit the program
        }
        
        cout << "SAL file successfully processed! Please select a command!" << endl << endl;
        cin >> input; // capture the user's input
        
        if(input == "s"){ // user wants to execute each line of code one by one
          Instruction * instruction = pc.getProgMemLocation(programCounter);
          instruction->execute(pc,programCounter);
          cout << instruction->getOpCode() << endl;
          if(instruction->getOpCode() != "JMP" || instruction->getOpCode() != "JZS" || instruction->getOpCode() != "JVS" ){
            programCounter++;
          }
          printInfo(pc);
          commandLoop(pc); // call the commandLoop again for so the user can continue looping through the program
        }
        else if(input == "a"){ // user wants all the instructions executed consecutively
          while(programCounter != pc.getInstructionCount()){
            Instruction * instruction = pc.getProgMemLocation(programCounter);
            instruction->execute(pc,programCounter);
          if(instruction->getOpCode() != "JMP" || instruction->getOpCode() != "JZS" || instruction->getOpCode() != "JVS" ){
            programCounter++;
          }
            printInfo(pc);
          }
          cout << "All instructions processed! Exiting..."; //program counter should be <= to instructionCount and therefore all instructions have been processed, time to exit
          exit(0);
        }
        else if(input == "q"){ // user wishes to exit the program
          cout << "q command selected! Exiting program..." << endl;
          exit(0); // q command entered, exit the program
        }        
      }

      void printInfo(Hardware pc) { // function for printing all the relevant information including the bits, registers, and both program and data memory
        cout << "-------~Program Memory~-------" << endl;
        for(int i = 0; i < pc.getInstructionCount(); i++){ // for loop handles printing out each program memory location's instruction
          cout << "instruction " + to_string(i) + ": ";
          pc.getProgMemLocation(i)->print(); // using the concrete method print defined in Instruction superclass
        }
        cout << "-------~End of Program Memory~-------" << endl << endl;
        cout << "-------~Data Memory~-------" << endl;
        for(int i = 0; i < 128; i ++ ){ // for loop handles printing out each data memory location that is populated
          if(pc.getDataMemLocation(i) != "0")
          cout << pc.getDataMemLocation(i) << endl;
        }
        cout << "-------~End of Data Memory~-------" << endl << endl;
        cout << "Accumulator: " + pc.getRegA() << endl; // print register A
        cout << "Additional Register: " + pc.getRegB() << endl; // print register B
        cout << "programCounter: " + to_string(programCounter) << endl; // print the program counter
        cout << "Zero Bit: " + to_string(pc.getZeroBit()) << endl; // print the zero bit
        cout << "Overflow Bit: " + to_string(pc.getOverflowBit()) << endl << endl; // print the overflow bit
      } // end of printInfo function

}; // end of ALI class




//////////////////////////////////////////////////////////////////////
///////////////////// END OF CLASS DEFINITIONS ///////////////////////
//////////////////////////////////////////////////////////////////////




int main() {
  Hardware pc; // hardware class declaration
  ALI interpreter; // ALI class declaration
  interpreter.readFile(pc); // read the file in and store the contents into Hardware's program memory
  interpreter.commandLoop(pc); // initiate the command loop
}


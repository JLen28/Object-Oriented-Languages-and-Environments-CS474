# coded by Joseph Lenaghan for CS474 at UIC | 10/16/22 | UIN: 676805596


$zero_result_bit = 0 # global variable that keeps track of the zero result bit
$overflow_bit = 0 # global variable that keeps track of the overflow bit

class Instruction # abstract superclass instruction that all instruction types will inherit from
  attr_reader :opCode, :argType,

  def operate() # deferred method for subclasses to implemented by children of Instruction

  end
end # end of instruction superclass that all the profound instructions will inherit from

class DEC < Instruction # DEC instruction class that inherits from instruction
  attr_accessor :decVal,:opCode,:argType
  def initialize(code,type,val)
    @opCode = code
    @argType = type
    @decVal = val
  end

  def operate(progMem) # operate method for DEC overwritten from super class
    i = 128 # the beginning of the ALI memory where data can be stored
    while(progMem.memoryBank[i] != 0) # check if the memory location is empty, if it isn't, try the next one
      if(progMem.memoryBank[i].to_s[0] == @decVal) # if the variable is already declared, there's no need to redeclare it
        return
      end
      i += 1
    end # once we've gotten here, that means we've found an empty memory location for the declared symbol
      progMem.memoryBank[i] = @decVal
  end

end # end of DEC instruction class

class LDA < Instruction # LDA instruction class that inherits from instruction
  attr_accessor :ldaVal,:opCode,:argType
  def initialize(code,type,val)
    @opCode = code
    @argType = type
    @ldaVal = val
  end

  def operate(mem) # operate method for LDA overwritten from super class
    i = 128
    while(mem.memoryBank[i] != 0)
      if(mem.memoryBank[i].to_s[0] == @ldaVal)
        j = 2
        substr = " "
        while(j < mem.memoryBank[i].to_s.length)
          substr.concat(mem.memoryBank[i].to_s[j])
          j += 1
        end
        return substr.to_i
      end
      i += 1
    end
  end

end # end of LDA instruction class

class LDB < Instruction # LDB instruction class that inherits from instruction
  attr_accessor :ldbVal,:opCode,:argType
  def initialize(code,type,val)
    @opCode = code
    @argType = type
    @ldbVal = val
  end

  def operate(mem) # operate method for LDA overwritten from super class
    i = 128
    while(mem.memoryBank[i] != 0)
      if(mem.memoryBank[i].to_s[0] == @ldbVal)
        j = 2
        substr = " "
        while(j < mem.memoryBank[i].to_s.length)
          substr.concat(mem.memoryBank[i].to_s[j])
          j += 1
        end
        return substr.to_i
      end
      i += 1
    end
  end

end # end of LDB instruction class

class LDI < Instruction # LDI instruction class that inherits from instruction
  attr_accessor :ldiVal,:opCode,:argType
  def initialize(code,type,val)
    @opCode = code
    @argType = type
    @ldiVal = val
  end

  def operate(regA) # operate method for LDI overwritten from super class
    regA.accuVal = @ldiVal
  end

end # end of LDI instruction class

class STR < Instruction # STR instruction class that inherits from instruction
  attr_accessor :strVal,:opCode,:argType

  def initialize(code,type,val)
    @opCode = code
    @argType = type
    @strVal = val
  end

  def operate(newVal,memory) # operate method for STR overwritten from super class
    i = 128
    while(i != 255)
      if(memory.memoryBank[i].to_s[0] == @strVal)
        puts "found a matching symbol"
        memory.memoryBank[i] = "#{@strVal}#{newVal}"
      end
      i += 1
    end
  end

end # end of STR instruction class

class Memory # memory for the emulator
  attr_accessor :memoryBank

  def initialize
    @memoryBank = Array.new(256,0)
  end
end # end of the memory class

class AccumulatorRegister
  attr_accessor :accuVal

  def initialize(passedVal)
    @accuVal = passedVal
  end

end # end of AccumulatorRegister class

class ExtraRegister
  attr_accessor :regVal

  def initialize(passedVal)
    @regVal = passedVal
  end

end # end of ExtraRegister class

class ProgramCounter
  attr_accessor :nextInstruction

  def initialize
    @nextInstruction = 0
  end

end # end of the ProgramCounter class
=begin
///////////////end of all class definitions, code below this line will all be related to overall program function and the command loop///////////////
=end
programMemory = Memory.new # program's memory bank is declared so we can store instructions into it
puts "please select a SAL file from the current Directory" # prompt the user to select a file for processing
input = gets.chomp # gather the input and prep it for reading from IO
instructions = IO.readlines(input) # read the lines of the input file and store them in an array called instructions
i = 0 # counter to loop through the array of instructions and the ALI's memory, starting at memory location zero
while(i != instructions.size && i < 128) # process instructions and store them in memory, remembering to not exceed location 127 as this other half of memory is reserved for storing values
  programMemory.memoryBank[i] = instructions[i] #storing instructions retrieved from the file into the ALI's memory
  i += 1 #increment counter to move through memory and the array of instructions
end
instructionCount = 0 # counter to be passed to commandloop to keep track of number of instructions



# puts block informing the user their file succesfully processed and informing them of the commands at their disposal
puts "File sucessfully processed!"
puts "-----=====-----=====-----=====-----=====-----=====-----=====-----"
puts "Please select from these commands to manipulate your file"
puts "s – Execute a single line of code, starting from the instruction at memory address 0; update the PC, the
registers and memory according to the instruction; and print the value of the registers, the zero bit, the
overflow bit, and only the memory locations that store source code or program data after the line is
executed."
puts "a – Execute all the instructions until a halt instruction is encountered or there are no more instructions to
be executed. The program’s source code and data used by the program are printed."
puts "q – Quit the command loop."
puts "-----=====-----=====-----=====-----=====-----=====-----=====-----"
# end of puts block that informs user of program functionality and confirms the file was processed successfully

def printResults(regA,regB,memory) # this function is responsible for displaying all the relevant info of the ALI and is called at the beginning of each commandLoop execution
  i = 0
  puts("----program's source code-----")
  while(i != 127)
    if(memory.memoryBank[i] != 0)
      puts "source code line: #{i} = #{memory.memoryBank[i]}"
    end
    i += 1
  end
  puts("----end of program's source code-----")
  puts("----program's data values-----")
  i = 128
  while(i != 255)
    if(memory.memoryBank[i] != 0)
      puts "Data code line: #{i} = #{memory.memoryBank[i]}"
    end
    i += 1
  end
  puts("----end of program's data values-----")
  puts("Register A value is: #{regA.accuVal}")
  puts("Register B value is: #{regB.regVal}")
  puts("zero bit is set to: #{$zero_result_bit}")
  puts("overflow bit is set to: #{$overflow_bit}")
  puts("\n\n")

end



def commandLoop(m,instructCount, a = AccumulatorRegister.new(0), b = ExtraRegister.new(0), pc = ProgramCounter.new()) # command loop that will be continually called until a halt is encountered or the user voluntarily ends the program
  regA = a # grab the register from the previous call, if this is the first call to command loop, then regA starts as zero
  regB = b # grab the register from the previous call, if this is the first call to command loop, then regB starts as zero
  progCounter = pc # grab the programCounter from the previous call, if this is the first call to command loop, then progCounter starts as zero
  progMem = m # grab the memory from teh commandLoop call
  numOfInstructions = instructCount # grab the nummber of processed instructions from the commandLoop
  printResults(regA,regB,progMem) # call the function to print all relevant information
  if(numOfInstructions == 1000) # as per the write-up, if one thousand instructions reached address the user and ask if they'd like to continue
    puts "One thousand instructions reached, program behavior is undocumented beyond this point, continue? Enter yes or no please"
    input = gets.chomp
    if(input == "no")
      exit
    end
  end
  if(progCounter.nextInstruction > 127) # safety check, if we go past this number, we are no longer reading from the portion of memory that is dedicated to instructions, meaning we're done by default, so exit the program
    puts("ceiling of instructions has been hit or there are no more instructions! exiting program to prevent undocumented behaviors!")
    exit
  end # end of programCounter safety check

  puts("current number of instructions processed: #{numOfInstructions}")
  puts "please enter a command to process your file!"
  input = gets.chomp # grab the input from the user and store it

  if(input == "q") # should the user enter a q, that means they wish to exit the program, so do so
    puts "Goodbye!"
    exit
  end # end of input q handling

  if(input == "s") # should the user enter s, that means they want one line of code executed, so do so
    puts "processing command for memory location #{progCounter.nextInstruction}"
    if(progMem.memoryBank[progCounter.nextInstruction] != 0)
      puts progMem.memoryBank[progCounter.nextInstruction] # display the instruction that will be executed
      instructArray = progMem.memoryBank[progCounter.nextInstruction].split # break the instruction string into its two relevant parts and store them in an array for further processing
      if(instructArray[0] == "DEC") # the command to be processed is of type DEC
        newInstruct = DEC.new('DEC','STRING',instructArray[1]) # make use of instruction subclass
        newInstruct.operate(progMem) # pass the program memory to be passed
        progCounter.nextInstruction = progCounter.nextInstruction + 1 # increment the program counter so we can process the next instruction
        commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
      end # end of behavior for DEC command

      if(instructArray[0] == "LDI") # the command to be processed is of type LDI
        if(instructArray[1].to_i > 2**31-1 || instructArray[1].to_i < -2**31) # check if the value is in range of 2's complement integers, if not, inform the user
          puts "value is out of range"
        else # the value is good and in range, process the instruction
          newInstruct = LDI.new('LDI','NUMBER',instructArray[1].to_i)
          newInstruct.operate(regA) # pass the 1st register to the instruction
          progCounter.nextInstruction = progCounter.nextInstruction + 1 # increment the program counter so we can process the next instruction
          commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
        end
      end # end of behavior for LDI command

      if(instructArray[0] == "STR") # the command to be processed is of type STR
        address = instructArray[1] # desired location of the value
        addressVal = "=" + regA.accuVal.to_s
        newInstruct = STR.new('STR','STRING',address)
        newInstruct.operate(addressVal,progMem)
        progCounter.nextInstruction = progCounter.nextInstruction + 1 # increment the program counter so we can process the next instruction
        commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
      end

      if(instructArray[0] == "LDA") # the command to be processed is of type LDA
        address = instructArray[1] # desired location to load value from
        newInstruct = LDA.new('LDA','STRING',address)
        regA.accuVal = newInstruct.operate(progMem) #update register A value
        progCounter.nextInstruction = progCounter.nextInstruction + 1 # increment the program counter so we can process the next instruction
        commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
      end

      if(instructArray[0] == "LDB") # the command to be processed is of type LDB
        address = instructArray[1] # desired location to load value from
        newInstruct = LDB.new('LDB','STRING',address)
        regB.regVal = newInstruct.operate(progMem) #update register B value
        progCounter.nextInstruction = progCounter.nextInstruction + 1 # increment the program counter so we can process the next instruction
        commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
      end

      if(instructArray[0] == "XCH") # the command to be processed is of type XCH
        value = regA.accuVal # temporarily keep track of register A's value
        regA.accuVal = regB.regVal # switch register value for A
        regB.regVal = value # switch register value for B to A's old value
        progCounter.nextInstruction = progCounter.nextInstruction + 1 # increment the program counter so we can process the next instruction
        commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
      end

      if(instructArray[0] == "JMP") # the command to be processed is of type JMP
        progCounter.nextInstruction = instructArray[1].to_i # change to the requested instruction
        commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
      end

      if(instructArray[0] == "JZS") # the command to be processed is of type JZS
        if($zero_result_bit == 1) # zero result bit is set, so adjust to teh requested instruction
          progCounter.nextInstruction = instructArray[1].to_i
          commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
        else # zero result bit is not set, skip over JZS instruction
          progCounter.nextInstruction = progCounter.nextInstruction + 1 # increment the program counter so we can process the next instruction
          commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
        end
      end

      if(instructArray[0] == "JVS") # the command to be processed is of type JVS
        if($overflow_bit == 1)
          progCounter.nextInstruction = instructArray[1].to_i # overflow bit is set, so adjust to the requested instruction
          commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
        else # overflow bit is not set, skip over jvs instruction
          progCounter.nextInstruction = progCounter.nextInstruction + 1 # increment the program counter so we can process the next instruction
          commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
        end
      end

      if(instructArray[0] == "ADD") # command to be processed is of typ
        result = regA.accuVal + regB.regVal # add the contents of the two registers together
        regA.accuVal = result # store the result of the addition into the register A
        if(result > 2**31 - 1 || result < -2**31) # if the value of the add transaction exceeds the range of 32 bit 2's complement integers, set the overflow bit!
          $overflow_bit = 1 # adjusting the overflow bit to reflect an overflow and allow use of JVS
          progCounter.nextInstruction = progCounter.nextInstruction + 1 # increment the program counter so we can process the next instruction
          commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
        elsif(result == 0) # if the value  of the add transaction results in zero then set the zero result bit!
          $zero_result_bit = 1 #adjusting the zero result bit to reflect a zero result and allow use of JZS
          progCounter.nextInstruction = progCounter.nextInstruction + 1 # increment the program counter so we can process the next instruction
          commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
        else
          $overflow_bit = 0
          $zero_result_bit = 0
          progCounter.nextInstruction = progCounter.nextInstruction + 1 # increment the program counter so we can process the next instruction
          commandLoop(progMem,numOfInstructions + 1,regA,regB,progCounter)
        end
      end

      if(instructArray[0] == "HLT") # command to be processed is a halt
        puts("Found a halt statement, exiting program")
        puts("^^ Final results displayed above ^^")
        exit # found a halt statement, time to exit
      end

    else # if we got here, that means that the we tried to process an instruction that was not there, inform the user of that fact and call commandLoop again
      puts "there is no instruction at memory location: #{progCounter.nextInstruction}"
      commandLoop(progMem,numOfInstructions,regA,regB,progCounter) # Because there is no instruction to be processed, we dont increment anything and we call the commandLoop once more
    end
  end # end of behavior for if the user enters an 's'

  if(input == "a") # user inputted an a, meaning they want the whole program executed at once
    while(progMem.memoryBank[progCounter.nextInstruction] != 0)
      puts "processing command for memory location #{progCounter.nextInstruction}"
      printResults(regA,regB,progMem)
      if(progMem.memoryBank[progCounter.nextInstruction] != 0)
        puts progMem.memoryBank[progCounter.nextInstruction] # display the instruction that will be executed
        instructArray = progMem.memoryBank[progCounter.nextInstruction].split # break the instruction string into its two relevant parts and store them in an array for further processing
        if(instructArray[0] == "DEC") # the command to be processed is of type DEC
          newInstruct = DEC.new('DEC','STRING',instructArray[1]) # make use of instruction subclass
          newInstruct.operate(progMem) # pass the program memory to be passed
        elsif(instructArray[0] == "LDI") # the command to be processed is of type LDI
          if(instructArray[1].to_i > 2**31-1 || instructArray[1].to_i < -2**31) # check if the value is in range of 2's complement integers, if not, inform the user
            puts "value is out of range"
          else # the value is good and in range, process the instruction
            newInstruct = LDI.new('LDI','NUMBER',instructArray[1].to_i)
            newInstruct.operate(regA) # pass the 1st register to the instruction
          end
        elsif(instructArray[0] == "STR") # the command to be processed is of type STR
          address = instructArray[1] # desired location of the value
          addressVal = "=" + regA.accuVal.to_s
          newInstruct = STR.new('STR','STRING',address)
          newInstruct.operate(addressVal,progMem)
        elsif(instructArray[0] == "LDA") # the command to be processed is of type LDA
          address = instructArray[1] # desired location to load value from
          newInstruct = LDA.new('LDA','STRING',address)
          regA.accuVal = newInstruct.operate(progMem) #update register A value
        elsif(instructArray[0] == "LDB") # the command to be processed is of type LDB
          address = instructArray[1] # desired location to load value from
          newInstruct = LDB.new('LDB','STRING',address)
          regB.regVal = newInstruct.operate(progMem) #update register B value
        elsif(instructArray[0] == "XCH") # the command to be processed is of type XCH
          value = regA.accuVal # temporarily keep track of register A's value
          regA.accuVal = regB.regVal # switch register value for A
          regB.regVal = value # switch register value for B to A's old value
        elsif(instructArray[0] == "JMP") # the command to be processed is of type JMP
          progCounter.nextInstruction = instructArray[1].to_i
          next
        elsif(instructArray[0] == "JZS") # the command to be processed is of type JZS
          if($zero_result_bit == 1) # zero result bit is set, so adjust to the requested instruction
            progCounter.nextInstruction = instructArray[1].to_i
            next
          end # otherwise, ignore the JZS instruction and move on
        elsif(instructArray[0] == "JVS") # the command to be processed is of type JVS
          if($overflow_bit == 1) # overflow bit is set, so adjust to the requested instruction
            progCounter.nextInstruction = instructArray[1].to_i
            next
          end # otherwise, ignore the JVS instruction and move on
        elsif(instructArray[0] == "ADD") # command to be processed is of typ
          result = regA.accuVal + regB.regVal # add the contents of the two registers together
          regA.accuVal = result # store the result of the addition into the register A
          if(result > 2**31 - 1 || result < -2**31) # if the value of the add transaction exceeds the range of 32 bit 2's complement integers, set the overflow bit!
            $overflow_bit = 1 # adjusting the overflow bit to reflect an overflow and allow use of JVS
          elsif(result == 0) # if the value  of the add transaction results in zero then set the zero result bit!
            $zero_result_bit = 1 #adjusting the zero result bit to reflect a zero result and allow use of JZS
          else # add is good and no bits need to be set, in fact, they should be cleared
            $overflow_bit = 0
            $zero_result_bit = 0
          end
        elsif(instructArray[0] == "HLT") # command to be processed is a halt
            puts("Found a halt statement, exiting program")
            puts("^^ Final results displayed above ^^")
            exit # found a halt statement, time to exit
        end # end of while loop that loops through each instruction

      else # if we got here, that means that the we tried to process an instruction that was not there, inform the user of that fact
        puts "there is no instruction at memory location: #{progCounter.nextInstruction}"
        exit # no more instructions to process, all done!
      end
        progCounter.nextInstruction += 1 # increment the program counter to guarantee execution
    end # end of the while loop that continuously executes till a halt is reached or there's no more instructions
  end

  # if we got here,the user entered something other than s,a or q.
  puts "input not recognized! Please try again."
  commandLoop(progMem,numOfInstructions,regA,regB,progCounter) # have to include this call just in case the user inputs something incorrectly, keep instruction count the same as nothing has been processed
end #end of the commandLoop

commandLoop(programMemory,instructionCount) # initial call to the commandLoop passing only the memory, as it is the only required parameter of the function and everything else will be passed in subsequent calls
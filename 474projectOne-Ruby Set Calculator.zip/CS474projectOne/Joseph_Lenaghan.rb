=begin
 Created by Joseph Lenaghan for CS 474 | Project One | 9/24/22
 program makes use of two major classes, Node and BST_set. Nodes are what make up a BST_set, each node has a left and right that can be used to attach new nodes depending on their value
=end


class Node # this class will be used in conjuction with the BST_set class
  # instance variables declared
   @left = nil
   @right = nil
   @value = nil

   attr_accessor(:value) # getter and setter for the Node's stored value
   attr_accessor(:left) # getter and setter for the node to the left of a porticular Node
   attr_accessor(:right) # getter and setter for the node to the right of a particular Node
  attr_accessor(:elements) # getter and setter for the list of ordered elements in the set (BST)

   def initialize(newVal)#constructor
     @value = newVal
   end
end # end of Node class

class BST_set # class that set's X, Y, and Z will use to store their elements


  def initialize(newBSTVal)#constructor
    @head = Node.new(newBSTVal)
    @elements = [ ] # array that will contain all the ordered elements for printing purposes
  end
  def self.new_noVal
    @head = nil
    @elements = nil
  end
  attr_accessor(:head)
  attr_accessor(:elements)

  def addNode(nodeVal) # method to add nodes to the BST, works off an infinite loop to achieve recursive like results without all the recursive fuss

    nuNode = Node.new(nodeVal)
    traverser = @head # traverser points to the head of the list,
    while true # Instead of doing this recursively, it makes more sense to me to make use of an infinite loop
      if(traverser == nil)
        self.head = nuNode
        break
      end

      if(nodeVal == traverser.value) # this check accounts for duplicates, we cannot have duplicates under any circumstances
        break
      end
      if(nodeVal > traverser.value) # if the new node value is greater than the head, it goes on the right, per BST
        if(traverser.right == nil) # if the head of the set currently has no right hand node
          traverser.right = nuNode
          break
        else
          traverser = traverser.right
          next
        end
      else # if we get here, the new node value is less than the head, so it goes on the left, per BST
        if(traverser.left == nil)
          traverser.left = nuNode
          break
        else
          traverser = traverser.left
          next
        end
      end
    end # end of infintite while loop
  end



  def in_order_traverser(curNode) # recursive function for gathering a list of elements as well as printing them using in order traversal
    traverser = curNode # the node we're currently examining
    unless(traverser.left == nil) # visiting left as long as we can
      in_order_traverser(traverser.left)
    end
    # once we've got here, we can no longer visit left, so we record the value we're at and then check right
    if(self.elements.include?(traverser.value) == false) # the nature of this recursive function will inevitably roll back to values already in the list, we don't want repeats, so ignore them
      self.elements.push(traverser.value) # add the value to the list of elements in ascending order
    end

    unless(traverser.right == nil) # checking the right hand side as per in order traversal, implementation follows the same structure as left visiting
      in_order_traverser(traverser.right)
    end
    if(self.elements.include?(traverser.value) == false) # the nature of this recursive function will inevitably roll back to values already in the list, we don't want repeats, so ignore them
      self.elements.push(traverser.value) # add the value to the list of elements in ascending order
    end
    return self.elements # all done, we can return the array now

  end # end of in_order_traverser

  def traverse # need a helper function to call
    in_order_traverser(self.head)
  end # end of traverse helper function

  def in_order_union(curNodeY) # function that is used to calculate the union of two sets using in order traversal
    traverserY = curNodeY # the node we're currently examining
    unless(traverserY.left == nil) # visiting left as long as we can
      in_order_union(traverserY.left)
    end
    # once we've got here, we can no longer visit left, so we record the value we're at and then check right
    if(self.elements.include?(traverserY.value) == false) # the nature of this recursive function will inevitably roll back to values already in the list, we don't want repeats, so ignore them
      self.elements.push(traverserY.value) # add the value to the list of elements in ascending order
      self.addNode(traverserY.value)
    end

    unless(traverserY.right == nil) # checking the right hand side as per in order traversal, implementation follows the same structure as left visiting
      in_order_union(traverserY.right)
    end
    if(self.elements.include?(traverserY.value) == false) # the nature of this recursive function will inevitably roll back to values already in the list, we don't want repeats, so ignore them
      self.elements.push(traverserY.value) # add the value to the list of elements in ascending order
      self.addNode(traverserY.value)
    end
  end # end of the function that is used to calculate union using in order traversal

  def do_union( set_y = BST_set.new_noVal) # helper function to call the in order union calculator function
    in_order_union(set_y.head)
  end # end of the do_union helper function


  def in_order_lambda(curNode,lambstring = " ") # code responsible for applying lambda functions in order
    lambdaCall = eval lambstring
    if(lambstring == " ")
      puts "lambda string is incompatible!"
    else
      traverser = curNode # the node we're currently examining
      unless(traverser.left == nil) # visiting left as long as we can
        in_order_lambda(traverser.left,lambstring)
      end
      # once we've got here, we can no longer visit left, so we record the value we're at and then check right

      unless(traverser.right == nil) # checking the right hand side as per in order traversal, implementation follows the same structure as left visiting
        in_order_lambda(traverser.right,lambstring)
      end
      puts "Lambda output"
      puts lambdaCall.call traverser.value
    end
  end # end of in_order_lambda


  def do_lambda(lambstring =  "") # helper function for in_order_lambda
    in_order_lambda(self.head,lambstring)
  end # end of the do_lambda helper function

  def checkIntersect(nodeVal,nuSet) # method that checks for duplicates in a given BST, need this to find the intersection
    traverser = @head # traverser points to the head of the list,
    while true # Instead of doing this recursively, it makes more sense to me to make use of an infinite loop
      if(traverser == nil)
        break
      end

      if(nodeVal == traverser.value) # this check accounts for duplicates, we cannot have duplicates under any circumstances, however, it is an easy route for finding the intersection, so we make use of it here to do so.
        if(nuSet == nil)
          nuSet = BST_set.new(nodeVal)
        else
          nuSet.addNode(nodeVal) # already been created, so add the node to the BST
        end
        break
      end
      if(nodeVal > traverser.value) # if the new node value is greater than the head, it goes on the right, per BST
        if(traverser.right == nil) # if the head of the set currently has no right hand node
          break
        else
          traverser = traverser.right # shift one node to the right
          next
        end
      else # if we get here, the new node value is less than the head, so it goes on the left, per BST
        if(traverser.left == nil)
          break
        else
          traverser = traverser.left # shift one not to the left
          next
        end
      end
    end # end of infintite while loop
    return nuSet
  end # end of the checkIntersect function

  def in_order_intersect(curNode,result) # function use to calculate the intersection of two sets using in_order_traversal
    traverser = curNode
    newSetX = result
    unless(traverser.left == nil) # visiting left as long as we can
      in_order_intersect(traverser.left,newSetX) # recursive call with the node to the left of this one
    end
    # once we've got here, we can no longer visit left, so we record the value we're at and then check right
    newSetX = self.checkIntersect(traverser.value,newSetX) # checking for a duplicate to help us form the intersection

    unless(traverser.right == nil) # checking the right hand side as per in order traversal, implementation follows the same structure as left visiting
      in_order_intersect(traverser.right,newSetX) # recursive call with the node to the right of this one
    end

    newSetX = self.checkIntersect(traverser.value,newSetX) # checking for a duplicate to help us form the intersection
    return newSetX
  end # end of in_order_intersect function

  def do_intersect(setY,resultSet) # helper function that calls the in_order_intersection set calculation
    newSet = in_order_intersect(setY.head,resultSet)
    return newSet # return the modified set

  end # end of do_intersect helper function

  def in_order_deep_copy(curNode,result) # function used to calculate a deep copy of two sets using in order traversal
    traverser = curNode
    newSetY = result # keeping track of the new set
    unless(traverser.left == nil) # visiting left as long as we can
      in_order_deep_copy(traverser.left,newSetY) # recursive call with the node to the left of this one
    end
    # once we've got here, we can no longer visit left, so we record the value we're at and then check right
    if(newSetY == nil)
      newSetY = BST_set.new(traverser.value) # has the set been declared yet? if not do so with a value to be deep copied
    else
      newSetY.addNode(traverser.value) # set has already been declared, so add node to it
    end

    unless(traverser.right == nil) # checking the right hand side as per in order traversal, implementation follows the same structure as left visiting
      in_order_deep_copy(traverser.right,newSetY) # recursive call with the node to the right of this one
    end
    if(newSetY == nil)
      newSetY = BST_set.new(traverser.value) # has the set been declared yet? if not do so with a value to be deep copied
    else
      newSetY.addNode(traverser.value) # set has already been declared, so add node to it
    end
    return newSetY # return the modified set
  end # end of the in order deep copy traversal function

  def do_deepCopy(setY,resultSet) # helper function for calling the function that calculates a deep copy using in order traversal
    newSet = in_order_deep_copy(self.head,resultSet)
    return newSet # return the modified set
  end # end of the do_deepCopy helper function
end # end of BST_set class





puts("-*-*-Welcome to my Set Calculator-*-*-")
puts("Here's a list of commands you can enter to utilize the calculator")
puts("----------------------------------------------------------------------------------------")
puts("X values — This command takes a comma-separated list of numeric arguments denoted by values. Now sets \n X is initialized to the values specified on the command line. The previous content of X is lost.")
puts("----------------------------------------------------------------------------------------")
puts("Y values — This command is similar to command X above, except that it resets the content of set Y")
puts("----------------------------------------------------------------------------------------")
puts("Z values — This command is similar to command X above, except that it resets the content of set Z.")
puts("----------------------------------------------------------------------------------------")
puts("a i — Numeric argument i is inserted in an appropriate location in set X. The other two sets are not modified. \n Of course, insertion must preserve the BST properties of set X.")
puts("----------------------------------------------------------------------------------------")
puts("r — The content of the 3 sets is rotated. Set Y takes the content of X; set Z takes the content of Y; and set X \n takes the previous content of Z. The BSTs are not modified or copied in this operation.")
puts("----------------------------------------------------------------------------------------")
puts("s — The contents of sets X and Y are switched. The BSTs are not modified or copied in this operation.")
puts("----------------------------------------------------------------------------------------")
puts("u — This command takes the union of sets X and Y. The result set is stored as X.")
puts("----------------------------------------------------------------------------------------")
puts("i — This command takes the intersection of sets X and Y. The result set is stored as X.")
puts("----------------------------------------------------------------------------------------")
puts("c — Set X is recursively deep copied into set Y. The previous content of Y is lost. After this command is \n executed, sets X and Y may not share any data structures.")
puts("----------------------------------------------------------------------------------------")
puts("l aString — This command takes a string argument defining a one-argument lambda expression. This lambda \n is applied to every element of set X. The result of each lambda execution is output on your console. Set X is \n not modified. You may assume that the syntax of the lambda in the string is correct.")
puts("----------------------------------------------------------------------------------------")
puts("q — This command quits the project.")
puts("----------------------------------------------------------------------------------------")



def printLists(x,y,z) # function that takes the relevant lists of this program and prints them as they are currently
  # this code handles printing the contents of each list after a command is executed
  puts("-~-contents of each list-~-")
  if (x != nil) # x is declared and in use
    puts("contents of X")
    x.elements.clear # need to reset the list of elements before we traverse, otherwise values that were added by the "a" command will be tacked onto the end as opposed to ascending order
    x.traverse # use traverser to gather the values in order
    i = 0 # counter to climb through list of  elements
    while(i != x.elements.size) # while loop to move through elements
       puts(x.elements[i]) # display the relevant element
      i += 1 #increment counter
    end
  else
    puts("X is empty!")
  end # end of the X content printing block
  if (y != nil)
    puts("contents of Y")
    y.traverse # use traverser to gather the values in order
    i = 0 # counter to climb through list of  elements
    while(i != y.elements.size) # while loop to move through elements
      puts(y.elements[i]) # display the relevant element
      i += 1 #increment counter
    end
  else
    puts("Y is empty!")
  end # end of the Y content printing block
  if (z != nil)
    puts("contents of Z")
    z.traverse # use traverser to gather the values in order
    i = 0 # counter to climb through list of  elements
    while(i != z.elements.size) # while loop to move through elements
      puts(z.elements[i]) # display the relevant element
      i += 1 #increment counter
    end
  else
    puts("Z is empty!")
  end # end of the Z content printing block
  puts("-~-end of contents of each list-~-")
end # end of the print lists function


def commandLoop(setX = BST_set.new_noVal,setY = BST_set.new_noVal,setZ = BST_set.new_noVal) # function that handles the program and the commands inputted by the user
  x = setX # set X
  y = setY # set Y
  z = setZ # set Z
  printLists(x,y,z) # need to print the lists after every command's execution
  puts("Please, enter a command: \n")
  command = gets # storing the users input into a string
  command = command.strip # make sure theres no whitespace
  if(command == 'q') # user inputted q, so quit the program
    puts("Goodbye!")
    exit
  end # end of code for "q" input

  if(command[0] == "X" && command[1] == " ") # user inputted X, time to add values to the set X and release old contents
    subStr = " " # need to use thing string to aid in string manipulation and storing a value
    x = nil # previous contents of X should vanish,this will account for that
    i = 2 # always start as position two, positions one should be the value denoting the call, in this case "X", and position two is the whitespace that seperates the call and the values intended for X
    while(i <= command.length)
      if(command[i] == "," || i == command.length) # if we got here, it means we've got a complete value we can store in X
        newVal = subStr.to_i
        subStr = " "
        if(x == nil) # if X hasn't been given any values yet, create a tree to store them
          x = BST_set.new(newVal)
        else # if we got here, that means that X is already has an exisiting BST
          x.addNode(newVal)
        end
      else
        subStr << command[i] # taking in another character from the command string
      end
      i += 1 # increment to the next value
    end
    commandLoop(x,y,z) # calling command loop again to keep the program running
  end # end of the code for "X" command input


  if(command[0] == "Y" && command[1] == " ") # user inputted Y, time to add values to the set Y and release old contents
    subStr = " " # need to use thing string to aid in string manipulation and storing a value
    y = nil # previous contents of X should vanish,this will account for that
    i = 2 # always start as position two, positions one should be the value denoting the call, in this case "X", and position two is the whitespace that seperates the call and the values intended for X
    while(i <= command.length)
      if(command[i] == "," || i == command.length) # if we got here, it means we've got a complete value we can store in X
        newVal = subStr.to_i
        subStr = " "
        if(y == nil) # if X hasn't been given any values yet, create a tree to store them
          y = BST_set.new(newVal)
        else # if we got here, that means that X is already has an exisiting BST
          y.addNode(newVal)
        end
      else
        subStr << command[i] # taking in another character from the command string
      end
      i += 1 # increment to the next value
    end
    commandLoop(x,y,z) # calling command loop again to keep the program running
  end # end of the code for "Y" command input


  if(command[0] == "Z" && command[1] == " ") # user inputted Z, time to add values to the set Z and release contents
    subStr = " " # need to use thing string to aid in string manipulation and storing a value
    z = nil # previous contents of X should vanish,this will account for that
    i = 2 # always start as position two, positions one should be the value denoting the call, in this case "X", and position two is the whitespace that separates the call and the values intended for X
    while(i <= command.length)
      if(command[i] == "," || i == command.length) # if we got here, it means we've got a complete value we can store in X
        newVal = subStr.to_i
        subStr = " "
        if(z == nil) # if X hasn't been given any values yet, create a tree to store them
          z = BST_set.new(newVal)
        else # if we got here, that means that X is already has an exisiting BST
          z.addNode(newVal)
        end
      else
        subStr << command[i] # taking in another character from the command string
      end
      i += 1 # increment to the next value
    end
    commandLoop(x,y,z) # calling command loop again to keep the program running
  end # end of the code for the "Z" command input


  if(command[0] == "a" && command[1] == " ") # user inputted the "a" command, so we must add a value to X whilst preserving BST functionality and maintain ascending order
    subStr = " " # string that will capture relevant part of the command
    i = 2 # starting past the "a " part of the command
    while(i < command.length) # making sure we grab the entire value, not a fraction of it
      subStr << command[i] # accumulating the input
      i += 1 #incrementing the counter
    end
    newVal = subStr.to_i # converting input into usable format
    if(x == nil)
      x = BST_set.new(newVal)
    else
      x.addNode(newVal) # add the node to the BST
    end
    commandLoop(x,y,z)  # calling command loop again to keep the program running
  end # end of the code for the "a" command input

  if(command[0] == "r") # user has inputted the command "r" calling for the rotation of all three sets
    commandLoop(z,x,y) # rotating the sets by calling command loop with altered arguments as requested by the input "r", rather elegant if I do say so myself :)
  end

  if(command[0] == "s") # user has inputted the command "s" calling for sets X and Y to switch values
    commandLoop(y,x,z) # switching the contents of x and y, as requested by the input "s"
  end

  if(command[0] == "u") # user has inputted the command "u" calling for the union of sets X and Y, which will be stored into X
    if(x == nil || y == nil)
      puts("set X or Y is empty, no union can be made")
    else
      x.do_union(y) # calling the in order union function
      commandLoop(x,y,z) # call the command loop again to keep program running
    end
  end

  if(command[0] == "i") # user has inputted the command "i", meaning they'd like the intersection of X and Y
    if(x == nil || y == nil)
      puts("set X or Y is empty, no intersection can be made!")
    else
      result = BST_set.new_noVal
      x = x.do_intersect(y,result) # calling the in order intersect function
      commandLoop(x,y,z) # call the command loop again to keep program running
    end
  end

  if(command[0] == "c") # user inputted the command "c" meaning that they wish to deep copy X into Y
    if(x == nil)
      puts("set X is empty, no Copy to be made!")

    else
      result = BST_set.new_noVal
      y = x.do_deepCopy(y,result) # calling the in order deepcopy function
      commandLoop(x,y,z) # call the command loop again to keep program running
    end
  end


  if(command[0] == "l" && command[1] == " ") # user inputted the command "l" and wants to apply a lambda function, as long as its acceptable,do so
    subStr = " " # string
    i = 2
    while(i < command.length)
      subStr << command[i]
      i += 1
    end
    x.do_lambda(subStr) # calling the in order lambda function
  end


  commandLoop(x,y,z) # need this call in case the user accidently enters the wrong input or messes it up
end # end of the command loop


#NEED THIS CALL TO START THE PROGRAM, OTHERWISE COMMAND LOOP IS NEVER CALLED!
commandLoop()
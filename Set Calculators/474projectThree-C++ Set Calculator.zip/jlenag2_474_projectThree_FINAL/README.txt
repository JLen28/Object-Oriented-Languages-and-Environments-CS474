coded by Joseph Lenaghan for CS474 project four at UIC | UIN : 676805596 | 11/2/22 | finished on 11/3/22
This program involves a basic set calculator that conducts computations between 2 sets, S1 and S2. There are several commands that the user can invoke to manipulate the sets, the commands are as follows:

'e' - Erase Set. Simply enter the character 'e' when prompted by the program. Doing so delete's the current set stored in S1, allowing the set to be refilled with new values. It is important to note that the previous
	value that was stored in S1 is lost forever.

's' - Switch Sets. Perform this command by entering the character 's' when prompted by the program switches the contents of S1 and S2, this can be done infinitely to the content of the user. This command is useful
	when you want to place multiple values into S2, Fill S1 with all the desired values you'd like in S2 and then swap the sets, S2 will hold the added values and S1 will be empty again.

'b' - Subset Operation. Perform this command by entering the character 'b' when prompted by the program compares sets S1 and S2 to determine whether or not S2 is a proper subset of S1. A set is deemed a proper subset
	of another set if all the elements in the subset exist in the set, but, the subset does not contain all the elements present in the set.

'c' - copy set. Entering 'c' when prompted by the program deep copies the contents of S1 into S2. the previous content of S2 is lost in this event.

'l' - list set contents. Entering 'l' when prompted by the program lists both S1 and S2 and all the elements contained within them, regardless of storage, the printed lists are displayed in alphabetical order.

'a' - add an element to S1. Entering the character 'a' when prompted by the program will cause another prompt to appear as well as another opportunity for the user to input,The program will ask what element
	the user would like to add to S1. Enter any string of characters like "longsword" or "dragon" (without the quotes) and hit enter for the addition to take affect. This element will be added into S1 while maintaining
	BST functionality inside S1.

'u' - take the union of S1 and S2. Perform this action by entering 'u' when prompted by the program. When entered this command takes the union of the two sets and stores them into S1, S1's previous contents are lost.
	This command effectively combines both sets into one set, and stores it into S1. S2 is not modified and retains its instance prior to the command execution.

'i' - take the intersection of S1 and S2. Perform this action by entering 'i' when prompted by the program. When entered this command takes the intersection of S1 and S2 and stores it into S1. S1's previous contents are lost,
	and S2's instance is retained and not modified. the intersection of two sets can be thought of as a set containing all of the elements S1 and S2 share in common.

'q' - Exit the program. Quits out of the command loop and prints the contents of S1 and S2 one last time.

When booting up the main.cpp file, the program will begin by asking the user to "select a command from teh list of commands described in the readme". This is when you will be able to start activating commands by entering them
into the terminal. The program itself relies on three classes. StringPlus,Node,and SetBST. SetBST does most of the heavy lifting and is the class responsible for maintaining S1 and S2. It handles all of the commands
and reflects changes in the reciever when necessary. Most of the command resolution is solved through recursively traversing the BST to perform operations. The Node class serves as the units that hold a string value and a pointer
to leafs that branch off it for the BST. It holds onto an instance of StringPlus and maintains the nodes in front of it. Without the Node class, writing the SetBST would be far more difficult and require alot of work arounds.
The StringPlus class was requested in the write-up and is the data type used most often in the program. This class stores the strings that will be held in nodes held in the BST.
	


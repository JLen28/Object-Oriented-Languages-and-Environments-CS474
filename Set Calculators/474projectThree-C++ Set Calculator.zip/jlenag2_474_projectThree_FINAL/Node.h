#include <iostream>
#include <cstring>
#include <iterator>
#include <vector>
#include <stdlib.h>
// coded by Joseph Lenaghan for CS474 project four at UIC | UIN : 676805596 | 11/2/22 

class Node { // node class to be used in conjuction with the BST 
  public :
  StringPlus value; // value held by the node
  Node* left; // node to the left of this one (less than node)
  Node* right; // node to the right of this one (greater than node)

  Node(){ // "default" constructor
    left = NULL;
    right = NULL;
  } // end of "default" constructor

  Node(StringPlus val){ // one argument constructor
    value = val;
    left = NULL;
    right = NULL;
  } // end of one arg constructor

  Node(const Node& n){ // copy constructor
    value = n.value;
    left = n.left;
    right = n.right;
  } // end of copy constructor


}; // end of the node class
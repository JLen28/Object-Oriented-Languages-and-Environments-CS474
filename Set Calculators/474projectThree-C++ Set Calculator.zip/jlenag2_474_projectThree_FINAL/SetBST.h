#include <iostream>
#include <cstring>
#include <iterator>
#include <vector>
#include <stdlib.h>
// coded by Joseph Lenaghan for CS474 project four at UIC | UIN : 676805596 | 11/2/22 

class SetBST { // "set" class that will operate as a BST
  public :

  Node head; // the top of the BST
  int size; // size of the BST, useful in a pinch

  SetBST(){ // "default" constructor
    size = 0;
  } // end of "default" constructor

  SetBST(Node nuHead){ // one argument constructor
    size = 0;
    head = nuHead;
    size++;
  } // end of one argument constructor


  SetBST(const SetBST& nuBST){ // copy constructor
    size = 1; 
    StringPlus headVal = nuBST.head.value; // extracting the StringPlus from the BST to be copied
    Node nuNode(headVal); // create a new Node to assure our head isn't shallow copied
    head = nuNode; // set the head to be the newly created node
    const Node* traverser = &nuBST.head; // creating a pointer of the BST to be copied's head so it can be processed in the recursive helper function
    copyConstructorHelper(traverser); // calling the recursive helper function with the pointer that was just created
    
  }
  ~SetBST(){
    Node* traverser = &head; // preparing a traversal pointer to walk down the BST
    destructorHelper(traverser); // calling a helper perfection allowing for recursive functionality
  }

  void destructorHelper(Node* curNode){
    if(curNode != NULL) // only performing this operation if the node is not null, otherwise an error is guaranteed
    {
    destructorHelper(curNode->left); // visit the left node
    destructorHelper(curNode->right); // visit the right node
    
    delete curNode->left; // deleting the dynamically allocated pointer's to each nodes left and right, compiler will destroy the rest
    delete curNode->right; 
    }
  }

  void add(Node* curTraverser,StringPlus value,Node nuNode){ // recursive add function called by add_helper, a function I am quite proud of :)
    if(strcmp(curTraverser->value._chars,value._chars) == 0){// if the head's string and the string to be added are duplicates, toss out the new string
      return;
    }
    if(curTraverser->value._size > value._size){ // traverser's string is longer so we'll loop by it to check lexographical ordering
      for(int i = 0; i < curTraverser->value._size; i++){ // looping to check lexographical ordering
        if(int(curTraverser->value._chars[i]) > int(value._chars[i]) || value._chars[i] == NULL){ // the character of traverser has a higher ascii value than the new string's character,go left also check if the shorter string has a null position, if it does, we automatically go left
          if(curTraverser->left == NULL){ // can't go left, it's null
            curTraverser->left = new Node(nuNode); // so the new node becomes the left of traverser
            size++; // increment the size of the BST
            return; // all done, return
          }
          else{
            return add(curTraverser->left,value,nuNode); // call add again with traverser's left node so that it can be compared
          }
        }
        else if(int(curTraverser->value._chars[i]) < int(value._chars[i])){ // the character of the new string has a higher ascii value than the traverser's character,go right
          if(curTraverser->right == NULL){ // can't go right, it's null
            curTraverser->right = new Node(nuNode); // so the new node becomes the right of traverser
            size++;
            return; // all done, return
          }
          else{
            return add(curTraverser->right,value,nuNode); // call add again with traverser's right node so that it can be compared
          }
        }
         // if we got here, the two characters compared are the same, so do nothing and move on to another for loop iteration
          
      } // end of for loop
      
    }
    else if(curTraverser->value._size < value._size){ //  the string to be added is of a larger size, so we'll loop by it to check lexographical ordering
      for(int i = 0; i < value._size; i++){ // looping to check lexographical ordering
        if(int(curTraverser->value._chars[i]) > int(value._chars[i])){ // the character of traverser has a higher ascii value than the new string's character,go left
          if(curTraverser->left == NULL){ // can't go left, it's null
            curTraverser->left = new Node(nuNode); // so the new node becomes the left of traverser
            size++;
            return; // all done, return
          }
          else{
            return add(curTraverser->left,value,nuNode); // call add again with traverser's left node so that it can be compared
          }
        }
        else if(int(curTraverser->value._chars[i]) < int(value._chars[i]) || curTraverser->value._chars[i] == NULL){ // the character of the new string has a higher ascii value than the traverser's character,go right, also check if the shorter string has a null position, if it does, we automatically go right
          if(curTraverser->right == NULL){ // can't go right, it's null
            curTraverser->right = new Node(nuNode); // so the new node becomes the right of traverser
            size++;
            return; // all done, return
          }
          else{
            return add(curTraverser->right,value,nuNode); // call add again with traverser's right node so that it can be compared
          }
        }
         // if we got here, the two characters compared are the same, so do nothing and move on to another for loop iteration
      } // end of for loop
      
    }
    else{ // strings are the same size, doesn't matter which one we loop by to check for lexographical ordering
      
      for(int i = 0; i < value._size; i++){ // looping to check lexographical ordering
        if(int(curTraverser->value._chars[i]) > int(value._chars[i])){ // the character of traverser has a higher ascii value than the new string's character,go left
          if(curTraverser->left == NULL){ // can't go left, it's null
            curTraverser->left = new Node(nuNode); // so the new node becomes the left of traverser
            size++;
            return; // all done, return
          }
          else{
            return add(curTraverser->left,value,nuNode); // call add again with traverser's left node so that it can be compared
          }
        }
        else if(int(curTraverser->value._chars[i]) < int(value._chars[i])){ // the character of the new string has a higher ascii value than the traverser's character,go right
          if(curTraverser->right == NULL){ // can't go right, it's null
            curTraverser->right = new Node(nuNode); // so the new node becomes the right of traverser
            size++;
            return; // all done, return
          }
          else{
            return add(curTraverser->right,value,nuNode); // call add again with traverser's right node so that it can be compared
          }
        }
         // if we got here, the two characters compared are the same, so do nothing and move on to another for loop iteration
      }// end of for loop
      
    }
  }// end of add recursive function 


  
  void add_helper(StringPlus value){ // need an add function to be able to add to the BST, this helper function calls that add function
    Node nuNode(value);
    if(head.value._chars == NULL || head.value._chars == ""){ // if the head isn't there, than this is the new head
      head = nuNode;
      return;
    }
    else if(std::strcmp(head.value._chars,value._chars) == 0){ // if the head's string and the string to be added are duplicates, toss out the new string
      return;
    }
    else{
      Node* traverser = &head; // if we've gotten to this point, it means some traversal needs to be done, so we declare a node to traverse the head
      add(traverser,value,nuNode); // initiate the recursive add function
    }
  } // end of add_helper helper function that calls recursive function add


  void printer(Node* curNode){ // print the set in alphabetical order
    if(curNode == NULL){ //if we encounter either a left or right that is null, we back up one call by calling return
      return;
    }
    printer(curNode->left); // visit the left node
    std::cout << curNode->value._chars << std::endl;
    printer(curNode->right); // visit the right node
    
  } // end of recursive alphabetical print function

  void copyConstructorHelper(const Node* curNode){ // recursive function called by the copy constructor to add all of the copied BST elements to this BST
    if(curNode == NULL){ // if we encountered a null left or right node, we can back up one call by calling return
      return;
    }
    this->add_helper(curNode->value); // add the value to the copy 
    copyConstructorHelper(curNode->left); // visit the left node
    copyConstructorHelper(curNode->right); // visit the right node
  } // end of copy constructor recursive function

  void print_list(){ // helper function that calls the recursive function that prints the set
    std::cout << "+=+=+= list of Elements =+=+=+" << std::endl;
    std::cout << "List Size: " << this->size - 1 << std::endl;
    Node* traverser = &head;
    printer(traverser);
    std::cout << "+=+=+= End of Elements =+=+=+" << std::endl;
  } // end of print_list helper function


  void do_union(SetBST s2){ // helper function that calls the copy constructorHelper to perform the union on S1
    Node* traverser = &s2.head;
    copyConstructorHelper(traverser); // save some time and reuse the code from the copy constructor
  } // end of do_union helper function


  void check_intersect(Node* curNode, char* value,SetBST& nuSet ){ //function responsible for checking if a given element in S2 exists in S1 for the sake of forming the intersection
    if(curNode == NULL){ // if we get here, we can back up one iteration with return
      return;
    }
    check_intersect(curNode->left,value,nuSet); // going left
    if(strcmp(curNode->value._chars,value) == 0){ // compare the strings at this location, if they match, then we can add them 
      StringPlus nuString(value); // create a new stringplus to be added to the intersection set
      nuSet.add_helper(nuString); // add the newly created string to the intersection set
    }
    check_intersect(curNode->right,value,nuSet); // going right
  } // end of check_intersect recurisve function

  void intersection(Node* curNode, Node* hedNode, SetBST& nuSet){ // this function recursively loops through each element in S2 and checks if it is present in S1
    if(curNode == NULL){ // if we get here, we can back up one iteration with return
      return;
    }
    intersection(curNode->left,hedNode,nuSet); // going left
    check_intersect(hedNode,curNode->value._chars,nuSet); // call check_intersect and pass nuSet so it can take the string if it is a part of S1
    intersection(curNode->right,hedNode,nuSet); // going right
  } // end of intersection recursive function

  SetBST do_intersect(SetBST s2){ // initial function called from the set that will call the intersection recursive function 
    StringPlus str1("");
    SetBST nuSet;
    nuSet.add_helper(str1); // this is the set that will hold the intersect of the two lists
    Node* traverser = &s2.head; // a pointer to traverse through S2
    Node* hedtraverser = &head; // a pointer to traverse through S1
    intersection(traverser,hedtraverser,nuSet); // passing to the first recursive function
    return nuSet;
  } // end of do_intersect helper function



  bool check_subset(SetBST s2){ // function used to determine if a subset exists between S1 and S2
    int counter = 0;
    StringPlus str1("");
    SetBST nuSet;
    nuSet.add_helper(str1); // this is the set that will hold the intersect of the two lists
    Node* traverser = &s2.head; // a pointer to traverse through S2
    Node* hedtraverser = &head; // a pointer to traverse through S1
    intersection(traverser,hedtraverser,nuSet); // the intersection function creates a subset with the common elements in S1 and S2, so we can reuse some code here
    std::cout << nuSet.size << std::endl;
    if(nuSet.size == 0){ // there are no elements in common with S1
      return 0;
    }
    else if(nuSet.size  > this->size -1){ // subset's size exceeds the size of S1 and can't be a subset
      return 0;
    }
    else if(nuSet.size == this->size - 1){ // subset but its contains all the elements of S1, not a proper subset
      return 0;
    }
    else{ // there exists elements in S2 that are in S1, enough to be a proper subset return 1
      return 1;
    }
  } // end of function responsible for checking for subset

}; // end of SetBST class
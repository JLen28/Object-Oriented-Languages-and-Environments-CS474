#include <iostream>
#include <cstring>
#include <iterator>
#include <vector>
#include <stdlib.h>
#include "StringPlus.h"
#include "Node.h"
#include "SetBST.h"
// coded by Joseph Lenaghan for CS474 project four at UIC | UIN : 676805596 | 11/2/22 


void commandLoop(SetBST s1, SetBST s2){ // command loop responsible for processing each of the user's input based on a keyword
  
  SetBST S1 = s1; // grab S1 from the previous call
  SetBST S2 = s2; // grab S2 from teh previous call
  
  std::cout << std::endl << std::endl; // provide some room in between each command loop execution
  std::string input = ""; // string to capture user input
  std::cout << "select a command from the list of commands described in the readme " << std::endl; // prompt the user to enter a command
  std::cin >> input; // capture the user input
  std::cout << std::endl; // provide some space inbetween the user input and oncoming text
  
  if(input[0] == 'q'){ // user wishes to quit the set calculator, print the lists and exit
    std::cout << "      --+-- Set S1 --+--      " << std::endl;
    S1.print_list(); // print the contents of S1
    std::cout << "----------------------------" << std::endl;
    std::cout << "      --+-- Set S2 --+--      " << std::endl;
    S2.print_list(); // print the contents of S2
    std::cout << "Goodbye!" << std::endl;
    return; // exiting back to main loop where the program will end
  } // end of behavior for 'q' command
  
  if(input[0] == 'a'){ // user selected a and wants to add an element to S1
    std::cout << "what element would you like to add to S1?" << std::endl; // prompt the user to choose an element they wish to add
    std::cin >> input; // capture that element
    char* newStr = strdup(input.c_str()); // shedding the constant tag through strdup, could just as easily right another constructor for const char arrays but this is simpler
    StringPlus nuStr(newStr); // create a new StringPlus to be added to the SetBST
    S1.add_helper(nuStr); // using the add function to add the item to the list
    return commandLoop(S1,S2);
  } // end of behavior for 'a' command
  
  if(input[0] == 'l'){ // user wishes to have the contents of both sets printed acts almost like q input without leaving the commandloop of course
    std::cout << "      --+-- Set S1 --+--      " << std::endl;
    S1.print_list();
    std::cout << "----------------------------" << std::endl;
    std::cout << "      --+-- Set S2 --+--      " << std::endl;
    S2.print_list();
    return commandLoop(S1,S2); // recall the commandLoop to prompt for another line of execution
  } // end of behavior for 'l' command


  if(input[0] == 'e'){ // user wishes to erase the contents of S1, so do so.
    SetBST nuSet;
    StringPlus str1("");
    nuSet.add_helper(str1);
    return commandLoop(nuSet,S2); // recall the commandLoop to prompt for another line of execution
  } // end of behavior for e command

  if(input[0] == 's'){ // user wants to swap sets
    return commandLoop(S2,S1); // do so by executing another recursive call and swapping the sets in said call
  } // end of behavior for s command

  if(input[0] == 'c'){ // user wants to copy set S1 into S2
    SetBST nuSet(S1); // use SetBST copy constructor accomplish this 
    return commandLoop(S1,nuSet); // return another commandLoop execution
  } // end of behavior for c command

  if(input[0] == 'u'){ // user wishes to take the union of S1 and S2
    S1.do_union(S2); // call the function to do the union passing S2
    return commandLoop(S1,S2); // return another commandLoop execution
  } // end of behavior for u command

  if(input[0] == 'i'){ // user wishes to take the intersection of S1 and S2
   SetBST nuSet(S1.do_intersect(S2));
   return commandLoop(nuSet,S2); // recall the commandLoop to prompt for another line of execution
  } // end of behavior for i command

  if(input[0] == 'b'){ // user wishes to check if the S2 is a proper subset of S1
    if(S1.check_subset(S2) == 1){
      std::cout << "S2 is indeed a proper subset of S1!" << std::endl; // informt he user that S2 is a proper subset of S1
      return commandLoop(S1,S2); // recall the commandLoop to prompt for another line of execution
    } // end of behavior for b command
    else{ 
       std::cout << "S2 is not a proper subset of S1!" << std::endl; // inform the user that S2 isn't a proper subset of S1
      return commandLoop(S1,S2); // recall the commandLoop to prompt for another line of execution
    } // end of catch all behavior
  }
  else{ // catch all in case the user incorrectly enters one of the command or accidently hits enter before completing the command
  std::cout << "command not recognized, please try again" << std::endl;
  return commandLoop(S1,S2); // recall the commandLoop to prompt for another line of execution
  }
  
} // end of the command loop function



int main() { // main function that kickstarts the commandLoop 
  StringPlus str1("");
  StringPlus str2("");
  SetBST s1; // set one that will be used in the calculator
  SetBST s2; // set two that will be used in the calculator
  s1.add_helper(str1); // initialize set one
  s2.add_helper(str2); // initialize set two
  commandLoop(s1,s2); // initial call to commandLoop to fire it up
  return 0;
} // end of main function

#include <iostream>
#include <cstring>
#include <iterator>
#include <vector>
#include <stdlib.h>
// coded by Joseph Lenaghan for CS474 project four at UIC | UIN : 676805596 | 11/2/22 

class StringPlus { // string class that was requested as per the write-up, implements the requested methods and data members
  public :
  int _size; // size of the string
  char* _chars; // the string


  StringPlus(){ // "default" constructor that can be called in a pinch
    _size = 0;
    _chars = NULL;
  } // end of "default" constructor

  StringPlus(char* value){ // constructor in which a value is passed
    _size = 0; // initializing size before finding it
    _chars = new char[std::strlen(value) + 1]; // allocating space for the copied value
    std::strcpy(_chars,value);
    int i = 0;
    while(value[i] != NULL){ // loop to gather the size
      _size++;
      i++;
    }
  } // end of one param constructor

  StringPlus(const StringPlus &nuString){ // copy constructor performs deep copy of the 
    _size = nuString._size;
    _chars = new char[std::strlen(nuString._chars) + 1]; // allocating space for the copied value
    std::strcpy(_chars,nuString._chars);
  } // end of copy constructor

  ~StringPlus(){ // destructor 
    _chars = NULL;
    delete[] _chars; // clearing up _chars so theres no memory leaks
  } // end of destructor

  void setString(char* value){ // replace the current string and recalculate it's size
    _size = 0; // initializing size before finding it
    _chars = new char[std::strlen(value) + 1]; // allocating space for the copied value
    std::strcpy(_chars,value);
    int i = 0;
    while(value[i] != NULL){ // loop to gather the size
      _size++;
      i++;
    }
  } // end of set string method

}; // end of the Stringplus class